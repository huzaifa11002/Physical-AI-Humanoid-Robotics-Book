try:
    import agents
    print("agents imported successfully")
    print(dir(agents))
except ImportError as e:
    print(f"ImportError: {e}")

try:
    from agents.run import Runner
    print("Runner imported successfully")
except ImportError as e:
    print(f"Runner ImportError: {e}")
