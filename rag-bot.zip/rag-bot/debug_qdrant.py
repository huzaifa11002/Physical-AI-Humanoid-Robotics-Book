import os
from dotenv import load_dotenv
from qdrant_client import QdrantClient
from pathlib import Path

load_dotenv()

def check_qdrant():
    api_key = os.getenv("QDRANT_API_KEY")
    url = os.getenv("QDRANT_URL")
    collection_name = "physical_ai_book"

    with open("debug_output.txt", "w") as f:
        f.write(f"Checking Qdrant at {url}...\n")
        try:
            client = QdrantClient(url=url, api_key=api_key)
            collections = client.get_collections()
            f.write("Connection successful!\n")
            
            exists = any(c.name == collection_name for c in collections.collections)
            if exists:
                info = client.get_collection(collection_name)
                f.write(f"Collection '{collection_name}' exists.\n")
                f.write(f"Points count: {info.points_count}\n")
            else:
                f.write(f"Collection '{collection_name}' does NOT exist.\n")
                
        except Exception as e:
            f.write(f"Qdrant Error: {e}\n")

        # Check Docs
        docs_dir = os.getenv("DOCS_DIR", str(Path(__file__).resolve().parent.parent / "docs"))
        path = Path(docs_dir)
        f.write(f"Checking docs path: {path}\n")
        if path.exists():
            f.write(f"Docs directory exists.\n")
            files = list(path.rglob("*.md")) + list(path.rglob("*.mdx"))
            f.write(f"Found {len(files)} markdown files.\n")
        else:
            f.write("Docs directory NOT found.\n")
