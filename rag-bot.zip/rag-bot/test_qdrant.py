import os
from dotenv import load_dotenv
from qdrant_client import QdrantClient

load_dotenv()

try:
    client = QdrantClient(
        url=os.getenv("QDRANT_URL"),
        api_key=os.getenv("QDRANT_API_KEY"),
    )
    
    collections = client.get_collections()
    print("✓ Qdrant connection successful!")
    print(f"Available collections: {[c.name for c in collections.collections]}")
    
    # Check if our collection exists
    collection_name = "physical_ai_book"
    if any(c.name == collection_name for c in collections.collections):
        info = client.get_collection(collection_name)
        print(f"✓ Collection '{collection_name}' exists with {info.points_count} points")
    else:
        print(f"⚠ Collection '{collection_name}' does not exist yet. Run ingest.py to create it.")
        
except Exception as e:
    print(f"✗ Qdrant connection failed: {e}")
